https://noobiecoderlol.github.io/Snake-game-KREP/
